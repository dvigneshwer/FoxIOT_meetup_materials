# FOXIOT Python cli

Command line program for the IOT Train LED experiment 


